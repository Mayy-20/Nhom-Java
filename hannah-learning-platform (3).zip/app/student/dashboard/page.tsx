"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  BookOpen,
  Clock,
  Trophy,
  Target,
  Play,
  Calendar,
  MessageCircle,
  Settings,
  LogOut,
  User,
  Bell,
} from "lucide-react"

export default function StudentDashboard() {
  const [user] = useState({
    name: "Nguyễn Văn A",
    email: "nguyenvana@email.com",
    avatar: "/placeholder.svg?height=40&width=40",
    joinDate: "Tháng 3, 2024",
    level: "Học viên tích cực",
  })

  const enrolledCourses = [
    {
      id: 1,
      title: "Python Căn Bản",
      progress: 75,
      totalLessons: 25,
      completedLessons: 19,
      nextLesson: "Hàm trong Python",
      instructor: "Nguyễn Văn A",
      image: "/placeholder.svg?height=120&width=200",
    },
    {
      id: 2,
      title: "JavaScript Nâng Cao",
      progress: 45,
      totalLessons: 35,
      completedLessons: 16,
      nextLesson: "Async/Await",
      instructor: "Lê Văn C",
      image: "/placeholder.svg?height=120&width=200",
    },
    {
      id: 3,
      title: "HTML & CSS",
      progress: 90,
      totalLessons: 20,
      completedLessons: 18,
      nextLesson: "CSS Grid Layout",
      instructor: "Trần Thị B",
      image: "/placeholder.svg?height=120&width=200",
    },
  ]

  const achievements = [
    {
      title: "Người học tích cực",
      description: "Hoàn thành 5 bài học trong tuần",
      icon: "🏆",
      earned: true,
    },
    {
      title: "Streak Master",
      description: "Học liên tục 7 ngày",
      icon: "🔥",
      earned: true,
    },
    {
      title: "Code Warrior",
      description: "Hoàn thành 100 bài tập",
      icon: "⚔️",
      earned: false,
    },
  ]

  const recentActivity = [
    {
      type: "lesson_completed",
      title: "Hoàn thành bài học",
      description: "Biến và kiểu dữ liệu - Python Căn Bản",
      time: "2 giờ trước",
    },
    {
      type: "quiz_passed",
      title: "Vượt qua bài kiểm tra",
      description: "Quiz: Cấu trúc điều khiển",
      time: "1 ngày trước",
    },
    {
      type: "course_enrolled",
      title: "Đăng ký khóa học mới",
      description: "React.js Framework",
      time: "3 ngày trước",
    },
  ]

  const stats = [
    {
      label: "Khóa học đang học",
      value: enrolledCourses.length,
      icon: BookOpen,
      color: "text-blue-600",
    },
    {
      label: "Giờ học tích lũy",
      value: "45",
      icon: Clock,
      color: "text-green-600",
    },
    {
      label: "Bài học hoàn thành",
      value: enrolledCourses.reduce((sum, course) => sum + course.completedLessons, 0),
      icon: Target,
      color: "text-purple-600",
    },
    {
      label: "Thành tích đạt được",
      value: achievements.filter((a) => a.earned).length,
      icon: Trophy,
      color: "text-yellow-600",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-teal-400 bg-clip-text text-transparent"
              >
                Hannah
              </Link>
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                Học viên
              </Badge>
            </div>

            <nav className="hidden md:flex space-x-8">
              <Link href="/student/dashboard" className="text-blue-600 font-medium">
                Dashboard
              </Link>
              <Link href="/courses" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Khóa học
              </Link>
              <Link href="/community" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Cộng đồng
              </Link>
              <Link href="/support" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Trợ giúp
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-5 w-5" />
              </Button>
              <div className="flex items-center space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar || "/placeholder.svg"} />
                  <AvatarFallback>{user.name[0]}</AvatarFallback>
                </Avatar>
                <span className="hidden md:block font-medium text-slate-700">{user.name}</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Chào mừng trở lại, {user.name}! 👋</h1>
          <p className="text-slate-600">Hãy tiếp tục hành trình học tập của bạn. Bạn đang làm rất tốt!</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600">{stat.label}</p>
                    <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                  </div>
                  <div className={`p-3 rounded-full bg-slate-100 ${stat.color}`}>
                    <stat.icon className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Enrolled Courses */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BookOpen className="h-5 w-5 mr-2 text-blue-600" />
                  Khóa học đang học
                </CardTitle>
                <CardDescription>Tiếp tục học tập để đạt được mục tiêu của bạn</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {enrolledCourses.map((course) => (
                    <div key={course.id} className="flex items-center space-x-4 p-4 bg-slate-50 rounded-lg">
                      <div className="w-20 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <h3 className="font-semibold text-slate-900 truncate">{course.title}</h3>
                        <p className="text-sm text-slate-600">Giảng viên: {course.instructor}</p>
                        <div className="flex items-center space-x-4 mt-2">
                          <div className="flex-1">
                            <div className="flex justify-between text-xs text-slate-600 mb-1">
                              <span>
                                {course.completedLessons}/{course.totalLessons} bài học
                              </span>
                              <span>{course.progress}%</span>
                            </div>
                            <Progress value={course.progress} className="h-2" />
                          </div>
                        </div>
                      </div>
                      <div className="flex flex-col space-y-2">
                        <Link href={`/courses/${course.id}`}>
                          <Button
                            size="sm"
                            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
                          >
                            <Play className="h-4 w-4 mr-1" />
                            Tiếp tục
                          </Button>
                        </Link>
                        <p className="text-xs text-slate-500 text-center">Tiếp theo: {course.nextLesson}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-6 text-center">
                  <Link href="/courses">
                    <Button variant="outline" className="bg-white text-slate-700 border-slate-300 hover:bg-slate-50">
                      Khám phá thêm khóa học
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-green-600" />
                  Hoạt động gần đây
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2" />
                      <div className="flex-1">
                        <h4 className="font-medium text-slate-900">{activity.title}</h4>
                        <p className="text-sm text-slate-600">{activity.description}</p>
                        <p className="text-xs text-slate-500 mt-1">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Profile Card */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader className="text-center">
                <Avatar className="h-20 w-20 mx-auto mb-4">
                  <AvatarImage src={user.avatar || "/placeholder.svg"} />
                  <AvatarFallback className="text-lg">{user.name[0]}</AvatarFallback>
                </Avatar>
                <CardTitle>{user.name}</CardTitle>
                <CardDescription>{user.email}</CardDescription>
                <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">{user.level}</Badge>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <User className="h-4 w-4 mr-2" />
                    Chỉnh sửa hồ sơ
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Settings className="h-4 w-4 mr-2" />
                    Cài đặt
                  </Button>
                  <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700">
                    <LogOut className="h-4 w-4 mr-2" />
                    Đăng xuất
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Achievements */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Trophy className="h-5 w-5 mr-2 text-yellow-600" />
                  Thành tích
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {achievements.map((achievement, index) => (
                    <div
                      key={index}
                      className={`flex items-center space-x-3 p-3 rounded-lg ${
                        achievement.earned ? "bg-yellow-50 border border-yellow-200" : "bg-slate-50"
                      }`}
                    >
                      <div className="text-2xl">{achievement.icon}</div>
                      <div className="flex-1">
                        <h4 className={`font-medium ${achievement.earned ? "text-yellow-800" : "text-slate-600"}`}>
                          {achievement.title}
                        </h4>
                        <p className={`text-xs ${achievement.earned ? "text-yellow-600" : "text-slate-500"}`}>
                          {achievement.description}
                        </p>
                      </div>
                      {achievement.earned && (
                        <Badge className="bg-yellow-500 text-white hover:bg-yellow-600">Đạt được</Badge>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Thao tác nhanh</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Link href="/courses">
                    <Button variant="outline" className="w-full justify-start">
                      <BookOpen className="h-4 w-4 mr-2" />
                      Tìm khóa học mới
                    </Button>
                  </Link>
                  <Link href="/community">
                    <Button variant="outline" className="w-full justify-start">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Tham gia cộng đồng
                    </Button>
                  </Link>
                  <Link href="/support">
                    <Button variant="outline" className="w-full justify-start">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Hỗ trợ
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
