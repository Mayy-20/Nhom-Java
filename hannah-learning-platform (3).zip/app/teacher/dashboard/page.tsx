"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  BookOpen,
  Users,
  MessageCircle,
  BarChart3,
  Plus,
  Edit,
  Eye,
  Trash2,
  Star,
  TrendingUp,
  Calendar,
  Bell,
  Settings,
  LogOut,
  GraduationCap,
  FileText,
  Video,
} from "lucide-react"

export default function TeacherDashboard() {
  const [user] = useState({
    name: "Nguyễn Văn A",
    email: "teacher@hannah.edu.vn",
    avatar: "/placeholder.svg?height=40&width=40",
    title: "Giảng viên Python",
    experience: "8 năm kinh nghiệm",
  })

  const stats = [
    {
      label: "Tổng học viên",
      value: "1,247",
      change: "+12%",
      icon: Users,
      color: "text-blue-600",
    },
    {
      label: "Khóa học đang dạy",
      value: "8",
      change: "+2",
      icon: BookOpen,
      color: "text-green-600",
    },
    {
      label: "Đánh giá trung bình",
      value: "4.8",
      change: "+0.2",
      icon: Star,
      color: "text-yellow-600",
    },
    {
      label: "Doanh thu tháng",
      value: "25.5M",
      change: "+18%",
      icon: TrendingUp,
      color: "text-purple-600",
    },
  ]

  const courses = [
    {
      id: 1,
      title: "Python Căn Bản",
      students: 456,
      rating: 4.8,
      status: "active",
      progress: 75,
      revenue: "12.5M VNĐ",
      lessons: 25,
      image: "/placeholder.svg?height=120&width=200",
    },
    {
      id: 2,
      title: "Python Nâng Cao",
      students: 234,
      rating: 4.9,
      status: "active",
      progress: 60,
      revenue: "8.2M VNĐ",
      lessons: 35,
      image: "/placeholder.svg?height=120&width=200",
    },
    {
      id: 3,
      title: "Data Science với Python",
      students: 189,
      rating: 4.7,
      status: "draft",
      progress: 40,
      revenue: "4.8M VNĐ",
      lessons: 42,
      image: "/placeholder.svg?height=120&width=200",
    },
  ]

  const students = [
    {
      id: 1,
      name: "Trần Thị B",
      email: "tranthib@email.com",
      course: "Python Căn Bản",
      progress: 85,
      lastActive: "2 giờ trước",
      avatar: "/placeholder.svg?height=32&width=32",
    },
    {
      id: 2,
      name: "Lê Văn C",
      email: "levanc@email.com",
      course: "Python Nâng Cao",
      progress: 67,
      lastActive: "1 ngày trước",
      avatar: "/placeholder.svg?height=32&width=32",
    },
    {
      id: 3,
      name: "Phạm Thị D",
      email: "phamthid@email.com",
      course: "Data Science",
      progress: 92,
      lastActive: "3 giờ trước",
      avatar: "/placeholder.svg?height=32&width=32",
    },
  ]

  const recentActivity = [
    {
      type: "new_student",
      title: "Học viên mới đăng ký",
      description: "Nguyễn Văn E đã đăng ký khóa Python Căn Bản",
      time: "5 phút trước",
      icon: Users,
    },
    {
      type: "assignment_submitted",
      title: "Bài tập được nộp",
      description: "Trần Thị B đã nộp bài tập Vòng lặp trong Python",
      time: "15 phút trước",
      icon: FileText,
    },
    {
      type: "question_asked",
      title: "Câu hỏi mới",
      description: "Lê Văn C đã đặt câu hỏi trong khóa Python Nâng Cao",
      time: "1 giờ trước",
      icon: MessageCircle,
    },
    {
      type: "review_received",
      title: "Đánh giá 5 sao",
      description: "Phạm Thị D đã đánh giá 5 sao cho khóa Data Science",
      time: "2 giờ trước",
      icon: Star,
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-teal-400 bg-clip-text text-transparent"
              >
                Hannah
              </Link>
              <Badge className="bg-gradient-to-r from-green-500 to-emerald-600 text-white hover:from-green-600 hover:to-emerald-700">
                <GraduationCap className="h-3 w-3 mr-1" />
                Giảng viên
              </Badge>
            </div>

            <nav className="hidden md:flex space-x-8">
              <Link href="/teacher/dashboard" className="text-blue-600 font-medium">
                Dashboard
              </Link>
              <Link
                href="/teacher/courses"
                className="text-slate-700 hover:text-blue-600 font-medium transition-colors"
              >
                Khóa học
              </Link>
              <Link
                href="/teacher/students"
                className="text-slate-700 hover:text-blue-600 font-medium transition-colors"
              >
                Học viên
              </Link>
              <Link
                href="/teacher/analytics"
                className="text-slate-700 hover:text-blue-600 font-medium transition-colors"
              >
                Thống kê
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-5 w-5" />
              </Button>
              <div className="flex items-center space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar || "/placeholder.svg"} />
                  <AvatarFallback>GV</AvatarFallback>
                </Avatar>
                <div className="hidden md:block">
                  <p className="font-medium text-slate-700">{user.name}</p>
                  <p className="text-xs text-slate-500">{user.title}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Chào mừng, {user.name}! 👨‍🏫</h1>
          <p className="text-slate-600">Quản lý khóa học và theo dõi tiến độ học viên của bạn</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card
              key={index}
              className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow"
            >
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600">{stat.label}</p>
                    <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                    <p className="text-sm text-green-600 font-medium">{stat.change} so với tháng trước</p>
                  </div>
                  <div className={`p-3 rounded-full bg-slate-100 ${stat.color}`}>
                    <stat.icon className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Quick Actions */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Thao tác nhanh</CardTitle>
                <CardDescription>Các tác vụ thường dùng để quản lý khóa học</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Button className="h-20 flex-col bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
                    <Plus className="h-6 w-6 mb-2" />
                    Tạo khóa học
                  </Button>
                  <Button
                    variant="outline"
                    className="h-20 flex-col bg-white text-slate-700 border-slate-300 hover:bg-slate-50"
                  >
                    <Video className="h-6 w-6 mb-2" />
                    Thêm bài học
                  </Button>
                  <Button
                    variant="outline"
                    className="h-20 flex-col bg-white text-slate-700 border-slate-300 hover:bg-slate-50"
                  >
                    <MessageCircle className="h-6 w-6 mb-2" />
                    Gửi thông báo
                  </Button>
                  <Button
                    variant="outline"
                    className="h-20 flex-col bg-white text-slate-700 border-slate-300 hover:bg-slate-50"
                  >
                    <BarChart3 className="h-6 w-6 mb-2" />
                    Xem báo cáo
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Courses Management */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle className="flex items-center">
                      <BookOpen className="h-5 w-5 mr-2 text-blue-600" />
                      Quản lý khóa học
                    </CardTitle>
                    <CardDescription>Theo dõi và quản lý các khóa học của bạn</CardDescription>
                  </div>
                  <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
                    <Plus className="h-4 w-4 mr-2" />
                    Tạo khóa học mới
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {courses.map((course) => (
                    <div key={course.id} className="flex items-center space-x-4 p-4 bg-slate-50 rounded-lg">
                      <div className="w-20 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex-shrink-0" />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="font-semibold text-slate-900">{course.title}</h3>
                          <Badge
                            className={
                              course.status === "active"
                                ? "bg-green-100 text-green-800"
                                : "bg-yellow-100 text-yellow-800"
                            }
                          >
                            {course.status === "active" ? "Hoạt động" : "Nháp"}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-4 text-sm text-slate-600">
                          <span className="flex items-center">
                            <Users className="h-4 w-4 mr-1" />
                            {course.students} học viên
                          </span>
                          <span className="flex items-center">
                            <Star className="h-4 w-4 mr-1 fill-yellow-400 text-yellow-400" />
                            {course.rating}
                          </span>
                          <span className="flex items-center">
                            <BookOpen className="h-4 w-4 mr-1" />
                            {course.lessons} bài học
                          </span>
                        </div>
                        <div className="mt-2">
                          <div className="flex justify-between text-xs text-slate-600 mb-1">
                            <span>Tiến độ hoàn thành</span>
                            <span>{course.progress}%</span>
                          </div>
                          <Progress value={course.progress} className="h-2" />
                        </div>
                      </div>
                      <div className="flex flex-col items-end space-y-2">
                        <div className="text-sm font-semibold text-green-600">{course.revenue}</div>
                        <div className="flex space-x-1">
                          <Button size="sm" variant="outline">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button size="sm" variant="outline" className="text-red-600 hover:text-red-700">
                            <Trash2 className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Students Management */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2 text-green-600" />
                  Quản lý học viên
                </CardTitle>
                <CardDescription>Theo dõi tiến độ và hoạt động của học viên</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {students.map((student) => (
                    <div key={student.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg">
                      <div className="flex items-center space-x-3">
                        <Avatar className="h-10 w-10">
                          <AvatarImage src={student.avatar || "/placeholder.svg"} />
                          <AvatarFallback>{student.name[0]}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-medium text-slate-900">{student.name}</h4>
                          <p className="text-sm text-slate-600">{student.email}</p>
                          <p className="text-xs text-slate-500">{student.course}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center space-x-2 mb-1">
                          <div className="w-20">
                            <Progress value={student.progress} className="h-2" />
                          </div>
                          <span className="text-sm font-medium">{student.progress}%</span>
                        </div>
                        <p className="text-xs text-slate-500">{student.lastActive}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-4 text-center">
                  <Button variant="outline" className="bg-white text-slate-700 border-slate-300 hover:bg-slate-50">
                    Xem tất cả học viên
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Profile Card */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader className="text-center">
                <Avatar className="h-20 w-20 mx-auto mb-4">
                  <AvatarImage src={user.avatar || "/placeholder.svg"} />
                  <AvatarFallback className="text-lg">GV</AvatarFallback>
                </Avatar>
                <CardTitle>{user.name}</CardTitle>
                <CardDescription>{user.title}</CardDescription>
                <Badge className="bg-green-100 text-green-800 hover:bg-green-200">{user.experience}</Badge>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <GraduationCap className="h-4 w-4 mr-2" />
                    Hồ sơ giảng viên
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Settings className="h-4 w-4 mr-2" />
                    Cài đặt
                  </Button>
                  <Button variant="outline" className="w-full justify-start text-red-600 hover:text-red-700">
                    <LogOut className="h-4 w-4 mr-2" />
                    Đăng xuất
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-purple-600" />
                  Hoạt động gần đây
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="p-2 bg-slate-100 rounded-full">
                        <activity.icon className="h-4 w-4 text-slate-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="font-medium text-slate-900 text-sm">{activity.title}</h4>
                        <p className="text-xs text-slate-600">{activity.description}</p>
                        <p className="text-xs text-slate-500 mt-1">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Stats */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Thống kê nhanh</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Câu hỏi chưa trả lời</span>
                    <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                      5
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Bài tập chờ chấm</span>
                    <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">
                      12
                    </Badge>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-slate-600">Đánh giá mới</span>
                    <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                      3
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
