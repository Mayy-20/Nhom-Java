"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Clock, Users, Star, Search, Filter, BookOpen, Play } from "lucide-react"

export default function CoursesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")
  const [selectedLevel, setSelectedLevel] = useState("all")

  const courses = [
    {
      id: 1,
      title: "Python Căn Bản",
      description: "Học các khái niệm lập trình cơ bản như biến, vòng lặp và hàm với Python - ngôn ngữ dễ học nhất",
      level: "Người mới bắt đầu",
      category: "Programming",
      duration: "10 giờ",
      students: 1250,
      rating: 4.8,
      lessons: 25,
      instructor: "Nguyễn Văn A",
      price: "Miễn phí",
      image: "/placeholder.svg?height=200&width=350",
    },
    {
      id: 2,
      title: "HTML & CSS",
      description: "Tạo trang web đầu tiên với HTML - khối xây dựng cơ bản của web và CSS để tạo kiểu",
      level: "Người mới bắt đầu",
      category: "Web Development",
      duration: "8 giờ",
      students: 980,
      rating: 4.7,
      lessons: 20,
      instructor: "Trần Thị B",
      price: "Miễn phí",
      image: "/placeholder.svg?height=200&width=350",
    },
    {
      id: 3,
      title: "JavaScript Nâng Cao",
      description: "Làm chủ JavaScript với các khái niệm nâng cao như async/await, closures và DOM manipulation",
      level: "Trung cấp",
      category: "Web Development",
      duration: "15 giờ",
      students: 756,
      rating: 4.9,
      lessons: 35,
      instructor: "Lê Văn C",
      price: "499,000 VNĐ",
      image: "/placeholder.svg?height=200&width=350",
    },
    {
      id: 4,
      title: "React.js Framework",
      description: "Xây dựng ứng dụng web hiện đại với React.js - thư viện JavaScript phổ biến nhất",
      level: "Nâng cao",
      category: "Web Development",
      duration: "20 giờ",
      students: 642,
      rating: 4.8,
      lessons: 40,
      instructor: "Phạm Thị D",
      price: "799,000 VNĐ",
      image: "/placeholder.svg?height=200&width=350",
    },
    {
      id: 5,
      title: "SQL Database",
      description: "Học cách quản lý cơ sở dữ liệu, viết truy vấn và tối ưu hóa hiệu suất với SQL",
      level: "Trung cấp",
      category: "Database",
      duration: "12 giờ",
      students: 534,
      rating: 4.6,
      lessons: 28,
      instructor: "Hoàng Văn E",
      price: "599,000 VNĐ",
      image: "/placeholder.svg?height=200&width=350",
    },
    {
      id: 6,
      title: "Machine Learning",
      description: "Khám phá thế giới AI với các thuật toán Machine Learning và ứng dụng thực tế",
      level: "Nâng cao",
      category: "AI & ML",
      duration: "25 giờ",
      students: 423,
      rating: 4.9,
      lessons: 50,
      instructor: "Ngô Thị F",
      price: "1,299,000 VNĐ",
      image: "/placeholder.svg?height=200&width=350",
    },
  ]

  const categories = [
    { value: "all", label: "Tất cả" },
    { value: "Programming", label: "Lập trình" },
    { value: "Web Development", label: "Phát triển Web" },
    { value: "Database", label: "Cơ sở dữ liệu" },
    { value: "AI & ML", label: "AI & Machine Learning" },
  ]

  const levels = [
    { value: "all", label: "Tất cả cấp độ" },
    { value: "Người mới bắt đầu", label: "Người mới bắt đầu" },
    { value: "Trung cấp", label: "Trung cấp" },
    { value: "Nâng cao", label: "Nâng cao" },
  ]

  const filteredCourses = courses.filter((course) => {
    const matchesSearch =
      course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.description.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || course.category === selectedCategory
    const matchesLevel = selectedLevel === "all" || course.level === selectedLevel

    return matchesSearch && matchesCategory && matchesLevel
  })

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-slate-200 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link
              href="/"
              className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-teal-400 bg-clip-text text-transparent"
            >
              Hannah
            </Link>

            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Trang chủ
              </Link>
              <Link href="/courses" className="text-blue-600 font-medium">
                Khóa học
              </Link>
              <Link href="/community" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Cộng đồng
              </Link>
              <Link href="/support" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Trợ giúp
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Link href="/login">
                <Button variant="outline" className="bg-white text-slate-700 border-slate-300 hover:bg-slate-50">
                  Đăng nhập
                </Button>
              </Link>
              <Link href="/register">
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
                  Đăng ký
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-24 pb-12 px-4 sm:px-6 lg:px-8 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-4">Khóa học của chúng tôi</h1>
          <p className="text-xl text-blue-100 mb-8 max-w-3xl mx-auto">
            Khám phá hàng trăm khóa học chất lượng cao được thiết kế bởi các chuyên gia hàng đầu
          </p>
        </div>
      </section>

      {/* Filters */}
      <section className="py-8 px-4 sm:px-6 lg:px-8 bg-white border-b">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
              <Input
                placeholder="Tìm kiếm khóa học..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <div className="flex gap-4">
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-48">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Danh mục" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((category) => (
                    <SelectItem key={category.value} value={category.value}>
                      {category.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select value={selectedLevel} onValueChange={setSelectedLevel}>
                <SelectTrigger className="w-48">
                  <SelectValue placeholder="Cấp độ" />
                </SelectTrigger>
                <SelectContent>
                  {levels.map((level) => (
                    <SelectItem key={level.value} value={level.value}>
                      {level.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>
      </section>

      {/* Courses Grid */}
      <section className="py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <p className="text-slate-600">Hiển thị {filteredCourses.length} khóa học</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredCourses.map((course) => (
              <Card
                key={course.id}
                className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 bg-white/80 backdrop-blur-sm"
              >
                <div className="aspect-video bg-gradient-to-br from-blue-500 to-purple-600 rounded-t-lg relative overflow-hidden">
                  <div className="absolute inset-0 bg-black/20" />
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-white/90 text-slate-700 hover:bg-white">{course.level}</Badge>
                  </div>
                  <div className="absolute top-4 right-4">
                    <Badge variant="secondary" className="bg-green-500 text-white hover:bg-green-600">
                      {course.price}
                    </Badge>
                  </div>
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <Button
                      size="lg"
                      className="bg-white/20 backdrop-blur-sm text-white border-white/30 hover:bg-white/30"
                    >
                      <Play className="h-5 w-5 mr-2" />
                      Xem trước
                    </Button>
                  </div>
                </div>

                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="outline" className="text-xs">
                      {course.category}
                    </Badge>
                    <div className="flex items-center text-sm text-slate-500">
                      <Star className="h-4 w-4 mr-1 fill-yellow-400 text-yellow-400" />
                      {course.rating}
                    </div>
                  </div>
                  <CardTitle className="text-xl group-hover:text-blue-600 transition-colors">{course.title}</CardTitle>
                  <CardDescription className="text-slate-600 line-clamp-2">{course.description}</CardDescription>
                </CardHeader>

                <CardContent>
                  <div className="flex items-center justify-between text-sm text-slate-500 mb-4">
                    <div className="flex items-center">
                      <BookOpen className="h-4 w-4 mr-1" />
                      {course.lessons} bài học
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {course.duration}
                    </div>
                    <div className="flex items-center">
                      <Users className="h-4 w-4 mr-1" />
                      {course.students.toLocaleString()}
                    </div>
                  </div>

                  <div className="flex items-center justify-between mb-4">
                    <div className="text-sm text-slate-600">
                      Giảng viên: <span className="font-medium">{course.instructor}</span>
                    </div>
                  </div>

                  <Link href={`/courses/${course.id}`}>
                    <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
                      Xem chi tiết
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredCourses.length === 0 && (
            <div className="text-center py-12">
              <BookOpen className="h-16 w-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-slate-600 mb-2">Không tìm thấy khóa học nào</h3>
              <p className="text-slate-500">Thử thay đổi bộ lọc hoặc từ khóa tìm kiếm</p>
            </div>
          )}
        </div>
      </section>
    </div>
  )
}
