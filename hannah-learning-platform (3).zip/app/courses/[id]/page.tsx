"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Textarea } from "@/components/ui/textarea"
import {
  Clock,
  Star,
  Play,
  FileText,
  Download,
  MessageCircle,
  ThumbsUp,
  Share2,
  BookOpen,
  CheckCircle,
  Lock,
  ArrowLeft,
} from "lucide-react"

export default function CourseDetailPage({ params }: { params: { id: string } }) {
  const [activeLesson, setActiveLesson] = useState(0)
  const [progress, setProgress] = useState(25)
  const [comment, setComment] = useState("")

  const course = {
    id: Number.parseInt(params.id),
    title: "Python Căn Bản",
    description:
      "Học các khái niệm lập trình cơ bản như biến, vòng lặp và hàm với Python - ngôn ngữ dễ học nhất cho người mới bắt đầu",
    level: "Người mới bắt đầu",
    duration: "10 giờ",
    students: 1250,
    rating: 4.8,
    instructor: {
      name: "Nguyễn Văn A",
      avatar: "/placeholder.svg?height=40&width=40",
      bio: "Chuyên gia Python với 8 năm kinh nghiệm",
    },
    objectives: [
      "Hiểu các khái niệm cơ bản của lập trình",
      "Viết được các chương trình Python đơn giản",
      "Sử dụng thành thạo các cấu trúc dữ liệu cơ bản",
      "Áp dụng Python vào giải quyết bài toán thực tế",
    ],
    requirements: [
      "Không cần kinh nghiệm lập trình trước đó",
      "Máy tính có thể cài đặt Python",
      "Tinh thần học hỏi và thực hành",
    ],
    lessons: [
      {
        id: 1,
        title: "Giới thiệu về Python",
        duration: "15 phút",
        type: "video",
        completed: true,
        preview: true,
      },
      {
        id: 2,
        title: "Cài đặt môi trường Python",
        duration: "20 phút",
        type: "video",
        completed: true,
        preview: false,
      },
      {
        id: 3,
        title: "Biến và kiểu dữ liệu",
        duration: "25 phút",
        type: "video",
        completed: false,
        preview: false,
      },
      {
        id: 4,
        title: "Toán tử trong Python",
        duration: "18 phút",
        type: "video",
        completed: false,
        preview: false,
      },
      {
        id: 5,
        title: "Cấu trúc điều khiển - If/Else",
        duration: "30 phút",
        type: "video",
        completed: false,
        preview: false,
      },
      {
        id: 6,
        title: "Vòng lặp For và While",
        duration: "35 phút",
        type: "video",
        completed: false,
        preview: false,
      },
      {
        id: 7,
        title: "Hàm trong Python",
        duration: "40 phút",
        type: "video",
        completed: false,
        preview: false,
      },
      {
        id: 8,
        title: "Danh sách (Lists)",
        duration: "28 phút",
        type: "video",
        completed: false,
        preview: false,
      },
    ],
    materials: [
      {
        name: "Slide bài giảng Python cơ bản",
        type: "pdf",
        size: "2.5 MB",
      },
      {
        name: "Source code các ví dụ",
        type: "zip",
        size: "1.2 MB",
      },
      {
        name: "Bài tập thực hành",
        type: "pdf",
        size: "800 KB",
      },
    ],
  }

  const comments = [
    {
      id: 1,
      user: {
        name: "Trần Thị B",
        avatar: "/placeholder.svg?height=32&width=32",
      },
      content: "Khóa học rất hay và dễ hiểu! Cảm ơn thầy đã giảng dạy tận tình.",
      time: "2 giờ trước",
      likes: 5,
    },
    {
      id: 2,
      user: {
        name: "Lê Văn C",
        avatar: "/placeholder.svg?height=32&width=32",
      },
      content: "Mình có thể hỏi về phần vòng lặp được không ạ? Có vẻ hơi khó hiểu.",
      time: "1 ngày trước",
      likes: 2,
    },
  ]

  const handleEnroll = () => {
    // Logic đăng ký khóa học
    alert("Đăng ký khóa học thành công!")
  }

  const handleLessonClick = (lessonIndex: number) => {
    if (lessonIndex <= 1 || course.lessons[lessonIndex].preview) {
      setActiveLesson(lessonIndex)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-slate-200 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/courses">
                <Button variant="ghost" size="sm">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Quay lại
                </Button>
              </Link>
              <Link
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-teal-400 bg-clip-text text-transparent"
              >
                Hannah
              </Link>
            </div>

            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Share2 className="h-4 w-4 mr-2" />
                Chia sẻ
              </Button>
            </div>
          </div>
        </div>
      </header>

      <div className="pt-16">
        {/* Course Hero */}
        <section className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-12">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2">
                <Badge className="bg-white/20 text-white hover:bg-white/30 mb-4">{course.level}</Badge>
                <h1 className="text-3xl md:text-4xl font-bold mb-4">{course.title}</h1>
                <p className="text-xl text-blue-100 mb-6">{course.description}</p>

                <div className="flex items-center space-x-6 mb-6">
                  <div className="flex items-center">
                    <Star className="h-5 w-5 mr-1 fill-yellow-400 text-yellow-400" />
                    <span className="font-semibold">{course.rating}</span>
                    <span className="text-blue-200 ml-1">({course.students.toLocaleString()} học viên)</span>
                  </div>
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 mr-1" />
                    <span>{course.duration}</span>
                  </div>
                  <div className="flex items-center">
                    <BookOpen className="h-5 w-5 mr-1" />
                    <span>{course.lessons.length} bài học</span>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <Avatar className="h-12 w-12">
                    <AvatarImage src={course.instructor.avatar || "/placeholder.svg"} />
                    <AvatarFallback>GV</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">{course.instructor.name}</p>
                    <p className="text-blue-200 text-sm">{course.instructor.bio}</p>
                  </div>
                </div>
              </div>

              <div className="lg:col-span-1">
                <Card className="bg-white/95 backdrop-blur-sm">
                  <CardHeader>
                    <div className="aspect-video bg-slate-200 rounded-lg mb-4 relative">
                      <div className="absolute inset-0 flex items-center justify-center">
                        <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white rounded-full w-16 h-16">
                          <Play className="h-6 w-6" />
                        </Button>
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600 mb-2">Miễn phí</div>
                      <Button
                        onClick={handleEnroll}
                        className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white mb-4"
                      >
                        Đăng ký học ngay
                      </Button>
                      <div className="text-sm text-slate-600">
                        <p>✓ Truy cập trọn đời</p>
                        <p>✓ Chứng chỉ hoàn thành</p>
                        <p>✓ Hỗ trợ 24/7</p>
                      </div>
                    </div>
                  </CardHeader>
                </Card>
              </div>
            </div>
          </div>
        </section>

        {/* Course Content */}
        <section className="py-12 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Tổng quan</TabsTrigger>
                <TabsTrigger value="curriculum">Chương trình học</TabsTrigger>
                <TabsTrigger value="materials">Tài liệu</TabsTrigger>
                <TabsTrigger value="discussion">Thảo luận</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="mt-8">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  <Card>
                    <CardHeader>
                      <CardTitle>Mục tiêu khóa học</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {course.objectives.map((objective, index) => (
                          <li key={index} className="flex items-start">
                            <CheckCircle className="h-5 w-5 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                            <span>{objective}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Yêu cầu</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ul className="space-y-2">
                        {course.requirements.map((requirement, index) => (
                          <li key={index} className="flex items-start">
                            <div className="w-2 h-2 bg-blue-500 rounded-full mr-3 mt-2 flex-shrink-0" />
                            <span>{requirement}</span>
                          </li>
                        ))}
                      </ul>
                    </CardContent>
                  </Card>
                </div>

                <Card className="mt-8">
                  <CardHeader>
                    <CardTitle>Tiến độ học tập</CardTitle>
                    <CardDescription>Bạn đã hoàn thành {progress}% khóa học</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Progress value={progress} className="h-3 mb-4" />
                    <div className="flex justify-between text-sm text-slate-600">
                      <span>
                        Đã học: {course.lessons.filter((l) => l.completed).length}/{course.lessons.length} bài
                      </span>
                      <span>{progress}% hoàn thành</span>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="curriculum" className="mt-8">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2">
                    <Card>
                      <CardHeader>
                        <CardTitle>Danh sách bài học</CardTitle>
                        <CardDescription>
                          {course.lessons.length} bài học • {course.duration}
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          {course.lessons.map((lesson, index) => (
                            <div
                              key={lesson.id}
                              className={`flex items-center justify-between p-4 rounded-lg border cursor-pointer transition-all ${
                                activeLesson === index ? "bg-blue-50 border-blue-200" : "bg-white hover:bg-slate-50"
                              } ${
                                index > 1 && !lesson.preview && !lesson.completed ? "opacity-60 cursor-not-allowed" : ""
                              }`}
                              onClick={() => handleLessonClick(index)}
                            >
                              <div className="flex items-center space-x-3">
                                <div className="flex-shrink-0">
                                  {lesson.completed ? (
                                    <CheckCircle className="h-5 w-5 text-green-500" />
                                  ) : index > 1 && !lesson.preview ? (
                                    <Lock className="h-5 w-5 text-slate-400" />
                                  ) : (
                                    <Play className="h-5 w-5 text-blue-500" />
                                  )}
                                </div>
                                <div>
                                  <h4 className="font-medium text-slate-900">{lesson.title}</h4>
                                  <div className="flex items-center space-x-2 text-sm text-slate-500">
                                    <Clock className="h-4 w-4" />
                                    <span>{lesson.duration}</span>
                                    {lesson.preview && (
                                      <Badge variant="outline" className="text-xs">
                                        Xem trước
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                              </div>
                              <Button
                                variant="ghost"
                                size="sm"
                                disabled={index > 1 && !lesson.preview && !lesson.completed}
                              >
                                {lesson.completed ? "Xem lại" : "Học ngay"}
                              </Button>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="lg:col-span-1">
                    <Card className="sticky top-24">
                      <CardHeader>
                        <CardTitle>Video bài học</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="aspect-video bg-slate-900 rounded-lg mb-4 relative">
                          <div className="absolute inset-0 flex items-center justify-center">
                            <Button
                              size="lg"
                              className="bg-white/20 backdrop-blur-sm text-white border-white/30 hover:bg-white/30 rounded-full w-16 h-16"
                            >
                              <Play className="h-6 w-6" />
                            </Button>
                          </div>
                        </div>
                        <h3 className="font-semibold mb-2">{course.lessons[activeLesson]?.title}</h3>
                        <p className="text-sm text-slate-600 mb-4">
                          Thời lượng: {course.lessons[activeLesson]?.duration}
                        </p>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            size="sm"
                            disabled={activeLesson === 0}
                            onClick={() => setActiveLesson(Math.max(0, activeLesson - 1))}
                          >
                            Bài trước
                          </Button>
                          <Button
                            size="sm"
                            disabled={activeLesson === course.lessons.length - 1}
                            onClick={() => setActiveLesson(Math.min(course.lessons.length - 1, activeLesson + 1))}
                            className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
                          >
                            Bài tiếp
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="materials" className="mt-8">
                <Card>
                  <CardHeader>
                    <CardTitle>Tài liệu khóa học</CardTitle>
                    <CardDescription>Tải xuống các tài liệu hỗ trợ học tập</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {course.materials.map((material, index) => (
                        <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                          <div className="flex items-center space-x-3">
                            <FileText className="h-8 w-8 text-blue-500" />
                            <div>
                              <h4 className="font-medium">{material.name}</h4>
                              <p className="text-sm text-slate-500">
                                {material.type.toUpperCase()} • {material.size}
                              </p>
                            </div>
                          </div>
                          <Button variant="outline" size="sm">
                            <Download className="h-4 w-4 mr-2" />
                            Tải xuống
                          </Button>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="discussion" className="mt-8">
                <div className="space-y-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Đặt câu hỏi</CardTitle>
                      <CardDescription>Chia sẻ thắc mắc hoặc thảo luận với cộng đồng</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <Textarea
                        placeholder="Nhập câu hỏi hoặc ý kiến của bạn..."
                        value={comment}
                        onChange={(e) => setComment(e.target.value)}
                        className="mb-4"
                      />
                      <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
                        <MessageCircle className="h-4 w-4 mr-2" />
                        Gửi câu hỏi
                      </Button>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>Thảo luận ({comments.length})</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        {comments.map((comment) => (
                          <div key={comment.id} className="flex space-x-3">
                            <Avatar className="h-8 w-8">
                              <AvatarImage src={comment.user.avatar || "/placeholder.svg"} />
                              <AvatarFallback>{comment.user.name[0]}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-1">
                                <span className="font-medium text-sm">{comment.user.name}</span>
                                <span className="text-xs text-slate-500">{comment.time}</span>
                              </div>
                              <p className="text-slate-700 mb-2">{comment.content}</p>
                              <div className="flex items-center space-x-4">
                                <Button variant="ghost" size="sm" className="text-slate-500 hover:text-blue-600">
                                  <ThumbsUp className="h-4 w-4 mr-1" />
                                  {comment.likes}
                                </Button>
                                <Button variant="ghost" size="sm" className="text-slate-500 hover:text-blue-600">
                                  <MessageCircle className="h-4 w-4 mr-1" />
                                  Trả lời
                                </Button>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </div>
    </div>
  )
}
