"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { MessageCircle, Users, BookOpen, TrendingUp, Star, Clock, User, ChevronRight } from "lucide-react"

export default function HomePage() {
  const [chatOpen, setChatOpen] = useState(false)
  const router = useRouter()

  const courses = [
    {
      id: 1,
      title: "Python Căn Bản",
      description: "Học các khái niệm lập trình cơ bản như biến, vòng lặp và hàm với Python",
      level: "Người mới bắt đầu",
      duration: "10 giờ",
      students: 1250,
      rating: 4.8,
      progress: 0,
      image: "/placeholder.svg?height=200&width=350",
    },
    {
      id: 2,
      title: "HTML & CSS",
      description: "Tạo trang web đầu tiên với HTML và CSS để tạo kiểu",
      level: "Người mới bắt đầu",
      duration: "8 giờ",
      students: 980,
      rating: 4.7,
      progress: 0,
      image: "/placeholder.svg?height=200&width=350",
    },
    {
      id: 3,
      title: "JavaScript Nâng Cao",
      description: "Làm chủ JavaScript với các khái niệm nâng cao như async/await, closures",
      level: "Trung cấp",
      duration: "15 giờ",
      students: 756,
      rating: 4.9,
      progress: 0,
      image: "/placeholder.svg?height=200&width=350",
    },
  ]

  const stats = [
    { label: "Học viên đã tham gia", value: "50,000+", icon: Users },
    { label: "Khóa học chất lượng", value: "100+", icon: BookOpen },
    { label: "Tỷ lệ hoàn thành cao", value: "95%", icon: TrendingUp },
    { label: "Hỗ trợ học tập", value: "24/7", icon: MessageCircle },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b border-slate-200 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <Link
                href="/"
                className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-teal-400 bg-clip-text text-transparent"
              >
                Hannah
              </Link>
            </div>

            <nav className="hidden md:flex space-x-8">
              <Link href="/" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Trang chủ
              </Link>
              <Link href="/courses" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Khóa học
              </Link>
              <Link href="/community" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Cộng đồng
              </Link>
              <Link href="/support" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Trợ giúp
              </Link>
              <Link href="/about" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Giới thiệu
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Link href="/login">
                <Button variant="outline" className="bg-white text-slate-700 border-slate-300 hover:bg-slate-50">
                  Đăng nhập
                </Button>
              </Link>
              <Link href="/register">
                <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
                  Đăng ký
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-24 pb-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-slate-900 mb-6">
              Học lập trình cùng{" "}
              <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">Hannah</span>
            </h1>
            <p className="text-xl text-slate-600 mb-8 max-w-3xl mx-auto">
              Khám phá thế giới công nghệ phần mềm với các khóa học tương tác, thực hành và cộng đồng hỗ trợ tận tình
            </p>

            <div className="bg-white/80 backdrop-blur-sm rounded-2xl p-6 max-w-md mx-auto mb-8">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium text-slate-700">Tiến độ học tập của bạn</span>
                <span className="text-sm font-bold text-blue-600">65%</span>
              </div>
              <Progress value={65} className="h-3 mb-2" />
              <p className="text-xs text-slate-500">65% hoàn thành khóa học</p>
            </div>

            <Link href="/courses">
              <Button
                size="lg"
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white px-8 py-3 text-lg"
              >
                Bắt đầu học ngay
                <ChevronRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Courses */}
      <section className="py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Khóa học nổi bật</h2>
            <p className="text-lg text-slate-600">Những khóa học được yêu thích nhất tại Hannah</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {courses.map((course) => (
              <Card
                key={course.id}
                className="group hover:shadow-xl transition-all duration-300 cursor-pointer border-0 bg-white/80 backdrop-blur-sm"
              >
                <div className="aspect-video bg-gradient-to-br from-blue-500 to-purple-600 rounded-t-lg relative overflow-hidden">
                  <div className="absolute inset-0 bg-black/20" />
                  <div className="absolute bottom-4 left-4">
                    <Badge className="bg-white/90 text-slate-700 hover:bg-white">{course.level}</Badge>
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl group-hover:text-blue-600 transition-colors">{course.title}</CardTitle>
                  <CardDescription className="text-slate-600">{course.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between text-sm text-slate-500 mb-4">
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-1" />
                      {course.duration}
                    </div>
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-1" />
                      {course.students.toLocaleString()}
                    </div>
                    <div className="flex items-center">
                      <Star className="h-4 w-4 mr-1 fill-yellow-400 text-yellow-400" />
                      {course.rating}
                    </div>
                  </div>
                  <Link href={`/courses/${course.id}`}>
                    <Button className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
                      Xem chi tiết
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-purple-600">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Hannah trong con số</h2>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-white/20 rounded-full mb-4">
                  <stat.icon className="h-8 w-8 text-white" />
                </div>
                <div className="text-3xl font-bold text-white mb-2">{stat.value}</div>
                <div className="text-blue-100">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-teal-400 bg-clip-text text-transparent mb-4">
                Hannah
              </div>
              <p className="text-slate-400">Nền tảng học lập trình trực tuyến hàng đầu Việt Nam</p>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-teal-400">Khóa học</h3>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Python
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    JavaScript
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    HTML/CSS
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    React.js
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-teal-400">Hỗ trợ</h3>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Trung tâm trợ giúp
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Liên hệ
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    FAQ
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Cộng đồng
                  </Link>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="font-semibold mb-4 text-teal-400">Về chúng tôi</h3>
              <ul className="space-y-2 text-slate-400">
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Giới thiệu
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Tuyển dụng
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Báo chí
                  </Link>
                </li>
                <li>
                  <Link href="#" className="hover:text-white transition-colors">
                    Điều khoản
                  </Link>
                </li>
              </ul>
            </div>
          </div>

          <div className="border-t border-slate-800 mt-8 pt-8 text-center text-slate-400">
            <p>&copy; 2025 Hannah. Tất cả quyền được bảo lưu.</p>
          </div>
        </div>
      </footer>

      {/* Chatbot */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          onClick={() => setChatOpen(!chatOpen)}
          className="w-14 h-14 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white shadow-lg"
        >
          <MessageCircle className="h-6 w-6" />
        </Button>

        {chatOpen && (
          <Card className="absolute bottom-16 right-0 w-80 h-96 shadow-xl">
            <CardHeader className="bg-gradient-to-r from-blue-600 to-purple-600 text-white rounded-t-lg">
              <CardTitle className="text-lg">Hannah AI</CardTitle>
              <CardDescription className="text-blue-100">Trợ lý học tập thông minh</CardDescription>
            </CardHeader>
            <CardContent className="p-4 h-64 overflow-y-auto">
              <div className="bg-slate-100 rounded-lg p-3 mb-4">
                <p className="text-sm">
                  Xin chào! Tôi là Hannah AI. Tôi có thể giúp bạn:
                  <br />• Tư vấn khóa học phù hợp
                  <br />• Giải đáp thắc mắc về lập trình
                  <br />• Hướng dẫn lộ trình học tập
                  <br />
                  <br />
                  Bạn cần hỗ trợ gì hôm nay? 😊
                </p>
              </div>
            </CardContent>
            <div className="p-4 border-t">
              <div className="flex space-x-2">
                <input
                  type="text"
                  placeholder="Nhập câu hỏi của bạn..."
                  className="flex-1 px-3 py-2 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <Button
                  size="sm"
                  className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white"
                >
                  Gửi
                </Button>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  )
}
