"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Users, BookOpen, Shield, TrendingUp, UserCheck, AlertTriangle, Bell } from "lucide-react"

export default function AdminDashboard() {
  const [user] = useState({
    name: "Admin Hannah",
    email: "admin@hannah.edu.vn",
    avatar: "/placeholder.svg?height=40&width=40",
    role: "Quản trị viên hệ thống"
  })

  const stats = [
    {
      label: "Tổng người dùng",
      value: "15,247",
      change: "+12%",
      icon: Users,
      color: "text-blue-600"
    },
    {
      label: "Khóa học hoạt động",
      value: "156",
      change: "+8",
      icon: BookOpen,
      color: "text-green-600"
    },
    {
      label: "Giảng viên",
      value: "89",
      change: "+5",
      icon: UserCheck,
      color: "text-purple-600"
    },
    {
      label: "Doanh thu tháng",
      value: "2.4B",
      change: "+23%",
      icon: TrendingUp,
      color: "text-yellow-600"
    }
  ]

  const users = [
    {
      id: 1,
      name: "Nguyễn Văn A",
      email: "nguyenvana@email.com",
      role: "student",
      status: "active",
      joinDate: "2024-01-15",
      courses: 3,
      avatar: "/placeholder.svg?height=32&width=32"
    },
    {
      id: 2,
      name: "Trần Thị B",
      email: "tranthib@email.com",
      role: "teacher",
      status: "active",
      joinDate: "2023-12-10",
      courses: 8,
      avatar: "/placeholder.svg?height=32&width=32"
    },
    {
      id: 3,
      name: "Lê Văn C",
      email: "levanc@email.com",
      role: "student",
      status: "pending",
      joinDate: "2024-03-20",
      courses: 1,
      avatar: "/placeholder.svg?height=32&width=32"
    }
  ]

  const courses = [
    {
      id: 1,
      title: "Python Căn Bản",
      instructor: "Nguyễn Văn A",
      students: 456,
      status: "active",
      revenue: "12.5M",
      rating: 4.8,
      createdDate: "2024-01-10"
    },
    {
      id: 2,
      title: "JavaScript Nâng Cao",
      instructor: "Trần Thị B",
      students: 234,
      status: "pending",
      revenue: "8.2M",
      rating: 4.9,
      createdDate: "2024-02-15"
    },
    {
      id: 3,
      title: "React.js Framework",
      instructor: "Lê Văn C",
      students: 189,
      status: "active",
      revenue: "6.8M",
      rating: 4.7,
      createdDate: "2024-03-01"
    }
  ]

  const communityPosts = [
    {
      id: 1,
      title: "Câu hỏi về Python loops",
      author: "Nguyễn Văn D",
      status: "pending",
      reports: 0,
      createdDate: "2024-03-25",
      content: "Tôi có thể hỏi về cách sử dụng vòng lặp for trong Python không?"
    },
    {
      id: 2,
      title: "Chia sẻ project React",
      author: "Trần Thị E",
      status: "approved",
      reports: 1,
      createdDate: "2024-03-24",
      content: "Mình vừa hoàn thành project React đầu tiên, muốn chia sẻ với mọi người"
    }
  ]

  const documents = [
    {
      id: 1,
      title: "Slide Python Cơ Bản",
      type: "pdf",
      author: "Nguyễn Văn A",
      status: "approved",
      size: "2.5 MB",
      uploadDate: "2024-03-20"
    },
    {
      id: 2,
      title: "Source Code JavaScript",
      type: "zip",
      author: "Trần Thị B",
      status: "pending",
      size: "1.8 MB",
      uploadDate: "2024-03-25"
    }
  ]

  const recentActivity = [
    {
      type: "user_registered",
      title: "Người dùng mới đăng ký",
      description: "Phạm Văn F đã tạo tài khoản học viên",
      time: "5 phút trước",
      icon: Users
    },
    {
      type: "course_submitted",
      title: "Khóa học chờ duyệt",
      description: "Hoàng Thị G đã gửi khóa học 'Vue.js Fundamentals'",
      time: "30 phút trước",
      icon: BookOpen
    },
    {
      type: "report_received",
      title: "Báo cáo vi phạm",
      description: "Bài đăng trong cộng đồng bị báo cáo spam",
      time: "1 giờ trước",
      icon: AlertTriangle
    }
  ]

  const getRoleColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-red-100 text-red-800'
      case 'teacher': return 'bg-blue-100 text-blue-800'
      case 'student': return 'bg-green-100 text-green-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800'
      case 'pending': return 'bg-yellow-100 text-yellow-800'
      case 'suspended': return 'bg-red-100 text-red-800'
      default: return 'bg-gray-100 text-gray-800'
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <Link href="/" className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-teal-400 bg-clip-text text-transparent">
                Hannah
              </Link>
              <Badge className="bg-gradient-to-r from-red-500 to-pink-600 text-white hover:from-red-600 hover:to-pink-700">
                <Shield className="h-3 w-3 mr-1" />
                Admin
              </Badge>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <Link href="/admin/dashboard" className="text-blue-600 font-medium">
                Dashboard
              </Link>
              <Link href="/admin/users" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Người dùng
              </Link>
              <Link href="/admin/courses" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Khóa học
              </Link>
              <Link href="/admin/community" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Cộng đồng
              </Link>
              <Link href="/admin/documents" className="text-slate-700 hover:text-blue-600 font-medium transition-colors">
                Tài liệu
              </Link>
            </nav>

            <div className="flex items-center space-x-4">
              <Button variant="ghost" size="sm">
                <Bell className="h-5 w-5" />
              </Button>
              <div className="flex items-center space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={user.avatar || "/placeholder.svg"} />
                  <AvatarFallback>AD</AvatarFallback>
                </Avatar>
                <div className="hidden md:block">
                  <p className="font-medium text-slate-700">{user.name}</p>
                  <p className="text-xs text-slate-500">{user.role}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-slate-900 mb-2">
            Bảng điều khiển Admin 🛡️
          </h1>
          <p className="text-slate-600">
            Quản lý toàn bộ hệ thống Hannah - người dùng, khóa học, cộng đồng và tài liệu
          </p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index} className="bg-white/80 backdrop-blur-sm border-0 shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-slate-600">{stat.label}</p>
                    <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
                    <p className="text-sm text-green-600 font-medium">
                      {stat.change} so với tháng trước
                    </p>
                  </div>
                  <div className={`p-3 rounded-full bg-slate-100 ${stat.color}`}>
                    <stat.icon className="h-6 w-6" />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Management Tabs */}
            <Card className="bg-white/80 backdrop-blur-sm border-0 shadow-lg">
              <CardHeader>
                <CardTitle>Quản lý hệ thống</CardTitle>
                <CardDescription>
                  Quản lý người dùng, khóa học, cộ\
